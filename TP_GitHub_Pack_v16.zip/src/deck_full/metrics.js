
async function renderMetrics(){
  try{
    const res = await fetch('../data/metrics.json');
    const m = await res.json();
    const set = (id, val)=>{const el=document.getElementById(id); if(el) el.textContent=val};
    // Investor
    set('m_mau', m.investor.MAU.toLocaleString());
    set('m_arpu', '$'+m.investor.ARPU.toFixed(0));
    set('m_cac', '$'+m.investor.CAC.toFixed(0));
    set('m_ltv', '$'+m.investor.LTV.toFixed(0));
    // Academy
    set('m_completion', (m.academy.cohort_completion*100).toFixed(0)+'%');
    set('m_compliance', (m.academy.journal_compliance*100).toFixed(0)+'%');
    set('m_attendance', (m.academy.attendance*100).toFixed(0)+'%');
    // Collective
    set('m_churn', (m.collective.churn*100).toFixed(1)+'%');
    set('m_retention', (m.collective.retention*100).toFixed(0)+'%');
    // Podcast
    set('m_downloads', m.podcast.downloads.toLocaleString());
    set('m_completion', (m.podcast.avg_completion*100).toFixed(0)+'%');
    set('m_subscribers', m.podcast.subscribers.toLocaleString());
  }catch(e){console.error('metrics',e)}
}
window.addEventListener('DOMContentLoaded', renderMetrics);
